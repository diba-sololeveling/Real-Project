/****************************************************************************
 *   2014, National Instruments, Corporation.  All Rights Reserved.         
 *---------------------------------------------------------------------------
 *                                                                          
 * Title:    ASLClientCodeExample.h                                        
 * Purpose:  ASLClientCodeExample declarations.                                
 *                                                                          
 ****************************************************************************/


#ifndef __ASL_H__
#define __ASL_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __ASL_H__ */
