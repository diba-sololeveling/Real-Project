Please install the following instrument drivers from IDNet:

Tektronix TDS 200 1000 2000 LV PnP Project Style   	https://sine.ni.com/apps/utf8/niid_web_display.download_page?p_id_guid=047216EC20B66FABE0440003BA7CCD71
Fluke 884x Series LV PnP Project Style      		http://sine.ni.com/apps/utf8/niid_web_display.download_page?p_id_guid=2EF8BF6ED2A54705E0440003BA7CCD71
hp33120a IVI Driver      				http://sine.ni.com/apps/utf8/niid_web_display.download_page?p_id_guid=E3B19B3E96B8659CE034080020E74861


and the following NI Modular instruments drivers from the NI Device Driver DVD:

NI-SCOPE
NI-SWITCH
NI-DMM   
NI-FGEN 


